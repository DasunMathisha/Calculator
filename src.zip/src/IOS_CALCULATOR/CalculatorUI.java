package IOS_CALCULATOR;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CalculatorUI extends JFrame implements ActionListener {

    private JTextField display;
    private double firstNumber = 0;
    private String operator = "";
    private boolean newNumber = true;

    public CalculatorUI() {

        setTitle("iOS Style Calculator");
        setSize(400, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        getContentPane().setBackground(Color.BLACK);
        setLayout(new BorderLayout(10, 10));

        // Display
        display = new JTextField("0");
        display.setFont(new Font("Arial", Font.BOLD, 42));
        display.setHorizontalAlignment(SwingConstants.RIGHT);
        display.setEditable(false);
        display.setBackground(Color.BLACK);
        display.setForeground(Color.WHITE);
        display.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

        add(display, BorderLayout.NORTH);

        // Button Panel
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 4, 10, 10));
        panel.setBackground(Color.BLACK);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        String[] buttons = {
                "AC", "+/-", "%", "/",
                "7", "8", "9", "*",
                "4", "5", "6", "-",
                "1", "2", "3", "+",
                "0", ".", "=", ""
        };

        for (String text : buttons) {

            if (text.equals("")) {
                panel.add(new JLabel());
                continue;
            }

            RoundedButton btn = new RoundedButton(text);
            btn.setFont(new Font("Arial", Font.BOLD, 24));
            btn.setFocusPainted(false);

            if (text.matches("[0-9.]")) {
                btn.setBackground(new Color(50, 50, 50));
                btn.setForeground(Color.WHITE);
            }
            else if (text.equals("AC")
                    || text.equals("+/-")
                    || text.equals("%")) {

                btn.setBackground(Color.LIGHT_GRAY);
                btn.setForeground(Color.BLACK);
            }
            else {
                btn.setBackground(Color.ORANGE);
                btn.setForeground(Color.WHITE);
            }

            btn.addActionListener(this);
            panel.add(btn);
        }

        add(panel, BorderLayout.CENTER);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        String cmd = e.getActionCommand();

        if ("0123456789".contains(cmd)) {

            if (newNumber) {

                display.setText(cmd);

                newNumber = false;
            }
            else {

                display.setText(display.getText() + cmd);
            }
        }

        else if (cmd.equals(".")) {

            if (!display.getText().contains(".")) {
                display.setText(display.getText() + ".");
            }
        }

        else if (cmd.equals("AC")) {

        	display.setText("0");

        	firstNumber = 0;

        	operator = "";

        	newNumber = true;
        }

        else if (cmd.equals("+/-")) {

            double value = Double.parseDouble(display.getText());
            value *= -1;
            display.setText(String.valueOf(value));
        }

        else if (cmd.equals("%")) {

            double value = Double.parseDouble(display.getText());
            value /= 100;
            display.setText(String.valueOf(value));
        }

        else if (cmd.equals("+")
                || cmd.equals("-")
                || cmd.equals("*")
                || cmd.equals("/")) {

            firstNumber =
                    Double.parseDouble(display.getText());

            operator = cmd;

            newNumber = true;
        }

        else if (cmd.equals("=")) {

            double secondNumber =
                    Double.parseDouble(display.getText());

            double result = 0;

            switch (operator) {

                case "+":
                    result = firstNumber + secondNumber;
                    break;

                case "-":
                    result = firstNumber - secondNumber;
                    break;

                case "*":
                    result = firstNumber * secondNumber;
                    break;

                case "/":

                    if (secondNumber == 0) {
                        display.setText("Error");
                        return;
                    }

                    result = firstNumber / secondNumber;
                    break;
            }

            if(result == (long) result)
            {
                display.setText(String.valueOf((long)result));
            }
            else
            {
                display.setText(String.valueOf(result));
            }

            newNumber = true;
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() ->
                new CalculatorUI());
    }
}

